/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'zh', {
	fontSize: {
		label: '大小',
		voiceLabel: '字型大小',
		panelTitle: '字型大小'
	},
	label: '字型',
	panelTitle: '字型名稱',
	voiceLabel: '字型'
} );
